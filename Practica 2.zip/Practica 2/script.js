class personaje
{
	constructor(nombre,score)
	{
		this.nombre = nombre;
		this.score = score;
	}
}

const p1 = new personaje('P1',5);
const p2 = new personaje('P2',5);


function atacarP1() 
{
	p2.score--;
	console.log(p2.score);
	document.getElementById("rhp").innerHTML = `Life points: ${p2.score}`;
	if(p2.score==0) 
	{
		alert("Gano P1");
		p2.score=5;
		p1.score=5;
		document.getElementById("lhp").innerHTML = `Life points: ${p1.score}`;
		document.getElementById("rhp").innerHTML = `Life points: ${p2.score}`;
	}
}

function atacarP2() 
{
	p1.score--;
	console.log(p1.score);
	document.getElementById("lhp").innerHTML = `Life points: ${p1.score}`;
	if(p1.score==0) 
	{
		alert("Gano P2");
		p2.score=5;
		p1.score=5;
		document.getElementById("lhp").innerHTML = `Life points: ${p1.score}`;
		document.getElementById("rhp").innerHTML = `Life points: ${p2.score}`;
	}
}

