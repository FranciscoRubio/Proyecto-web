class personaje
{
	constructor(nombre,forma,posicion)
	{
		this.nombre = nombre;
		this.forma = forma;
		this.posicion = posicion;
	}

	obtDetalles(mensaje)
	{
		alert(mensaje);
	}

}

class ave extends personaje
{
	
	constructor(nombre,forma,posicion,habilidad, masa)
	{
		super(nombre,forma,posicion);
		this.habilidad =habilidad;
		this.masa= masa;
		this.volar=function() 
		{
			console.log("Estoy volando");
		}
	}
	detalle() 
	{
		super.obtDetalles("Detalle de "+this.nombre+ ": \nForma: "+this.forma+"\nPosicion: "+this.posicion+"\nHabilidad: "+this.habilidad+"\nMasa:"+this.masa);
	}

}

class cerdo extends personaje
{
	constructor(nombre,forma,posicion,fortaleza, puntos)
	{
		super(nombre,forma,posicion);
		this.fortaleza =fortaleza;
		this.puntos= puntos;
		this.morir= function() 
		{
			console.log("Estoy muerto");
		}
	} 
	detalle()
	{
		super.obtDetalles("Detalle de "+this.nombre+ ": \nForma: "+this.forma+"\nPosicion: "+this.posicion+"\nFortaleza: "+this.fortaleza+"\nPuntos:"+this.puntos);
   	}
}

const AB1 = new ave("Pedro","av1p.png","ave1","Bumerang",3);
const AB2 = new ave("Maria","av2p.png","ave2","Explotar",5);
const AB3 = new ave("Monse","av3p.png","ave3","Golpe",10);

const cer1 = new cerdo("Enrique","cerdop.png","cerdo1",5,10);
const cer2 = new cerdo("Carlos","cerdop.png","cerdo2",5,10);
const cer3 = new cerdo("Gustavo","cerdop.png","cerdo3",10,20);

function cargarImagenes()
{
 	var a1 = document.getElementById(AB1.posicion);
    a1.innerHTML = '<img src=' + AB1.forma +' height="150" width="150">';

    var a2 = document.getElementById(AB2.posicion);
    a2.innerHTML = '<img src=' + AB2.forma +' height="150" width="150">';

    var a3 = document.getElementById(AB3.posicion);
    a3.innerHTML = '<img src=' + AB3.forma +' height="150" width="150">';

    var c1 = document.getElementById(cer1.posicion);
    c1.innerHTML = '<img src=' + cer1.forma +' height="150" width="150">';

    var c2 = document.getElementById(cer2.posicion);
    c2.innerHTML = '<img src=' + cer2.forma +' height="150" width="150">';

    var c3 = document.getElementById(cer3.posicion);
    c3.innerHTML = '<img src=' + cer3.forma +' height="150" width="150">';
}