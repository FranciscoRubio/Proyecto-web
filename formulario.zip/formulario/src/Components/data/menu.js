export default[
    {
        title:'Home',
        url:'/'
    },
    {
        title:'Blog',
        url:'/blog'
    },
    {
        title:'About us',
        url:'/About'
    },
    {
        title:'Contact us',
        url:'Contact'
    }
];
