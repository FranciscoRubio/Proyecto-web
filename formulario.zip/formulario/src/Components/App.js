import React,{Component} from 'react';
import './Global/css/App.css';
import Header from './Global/Header';
import Footer from './Global/Footer';
import Content from './Global/Content';
import Form from './Global/Form';
import PropTypes from 'prop-types';


class App extends Component
{
  static propTypes =
  {
    children:PropTypes.object.isRequired
  };


  render()
  {
    const {children} = this.props;

    return(
    <div className="App">
      <Header/>
      <Content/>
      <Form  body={children}/>
      <Footer/>
    </div>
    );
  };
}

export default App;
