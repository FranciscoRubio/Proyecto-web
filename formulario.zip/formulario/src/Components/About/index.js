import React,{Component} from 'react';
import '../Global/css/about.css';
import img from '../Global/images/petcare.jpg';

class About extends Component
{
    render(){
        return(
            <div className="mision">
                <h1> La misión de Timothy’s pet care co. Es brindar a los clientes  facilidad en el control y monitoreo Alimenticio de sus mascotas, ofreciendo productos de calidad y calidez. </h1>
                <img src={img} className="about-logo" alt="logo"/>
            </div>
        );
    }
}

export default About;