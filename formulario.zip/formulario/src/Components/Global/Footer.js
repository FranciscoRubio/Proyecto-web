import React, {Component} from 'react';
import './css/Footer.css';
import logo from './images/Logo.gif';
import logofb from './images/fbicon.png';
import logotw from './images/logotwit.png';

class Footer extends Component
{
    render()
    {
    
        return(

            <div className="datos">
                <img src={logo} className="logo-footer" alt="logo"/>
                <h4 className ="contact">CONTACTANOS EN !</h4>
                <a href="https://www.facebook.com/francisco.rubio95">
                <img src={logofb} className="logo-fb" alt="logofb"/>
                </a>
                <a href="https://twitter.com/francico_rubio">
                <img src={logotw} className="logo-tw" alt="logotw"/>
                </a>
                

                <h4 className ="textfooter">
                    Autores:<br/>
                    Cortes Herrera Monserrat<br/>
                    Rubio Higuera Francisco A.
                </h4>
            </div>
        );
    };
}

export default Footer;