import React,{Component} from 'react';
import './css/form.css';

import PropTypes from 'prop-types';

class Form extends Component
{
    static propTypes = {
        body:PropTypes.object.isRequired
    }
    render()
    {
        const {body} = this.props;
        return(
            <div className ="form">
                {body}
            </div>
        );
    };
}

export default Form;