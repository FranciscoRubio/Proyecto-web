import React, {Component} from 'react';
import logo from './images/Logo-Oficial.gif';
import './css/Header.css';
import {Link} from 'react-router-dom';
import PropTypes from 'prop-types';
import items from '../data/menu';


class Header extends Component
{
    static propTypes =
    {
        title:PropTypes.string.isRequired,
        items:PropTypes.array.isRequired
    };

    render()
    {
        //const {title,items}= this.props;
        return(
            <div className="Header">
                <header className="logo">
                    <img src={logo} className="header-logo" alt="logo"/>
                    <ul className="Menu">
                        {items.map((item,key)=><li key={key}><Link to={item.url}>{item.title}</Link></li>)}
                    </ul>
                </header>
            </div>
        );
    };
}

export default Header;