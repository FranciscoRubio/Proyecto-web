import React,{ Component } from 'react';
import './css/Content.css';
import { thisExpression } from '@babel/types';
import img from './images/pet-collar.png';

class Content extends Component {

    constructor(){
        //react necesita la palabra super para poder utilizar this
        super();
        //crear un state (objeto)
        this.state = {
            firstName: 'Juan',
            lastName: 'Perez',
            BirthDate: new Date(),
            Email: '',
            Address:'',
            Phone:'',
            Gender:'',
        };

        this.handleInputChange =this.handleInputChange.bind(this);
        this.handleResultClick =this.handleResultClick.bind(this);
      
    }

    handleInputChange(event){

      
        if(event.target.id === "RI1")
        {
            this.setState({firstName:event.target.value});
        
        }
        else if(event.target.id === "RI2"){
            this.setState({lastName:event.target.value});
            
        }
        else if(event.target.id === "RI3"){
            this.setState({BirthDate:event.target.value});
        }
        else if(event.target.id === "RI4"){
            this.setState({Email:event.target.value});
        }
        else if(event.target.id === "RI5"){
            this.setState({Address:event.target.value});

        }
        else if(event.target.id === "RI6"){
            this.setState({Phone:event.target.value});
        }
        else if(event.target.id ==="RI7"){
            this.setState({Gender:event.target.value});
        }
        
      }

      handleResultClick(e){
        if(e.target.id==="Enviar"){
             
             alert("Name: "+ this.state.firstName + "\nLast Name: " + this.state.lastName + "\nBirthDate:" + this.state.BirthDate + "\nE-mail:" +this.state.Email + 
             "\nAddress:" + this.state.Address + "\nPhone:"+this.state.Phone + "\nGender:"+this.state.Gender);
            
        }
    }


    render() {
        const {body} =this.props;
          return(
        <div className="Content">

               <section id="Contenedor">

                   <section id="Principal">

                       <form id="Registro">
                              
                       <h1 id="title-SignUp">Sign Up</h1>
                       <p><input id="RI1" type="text" onChange={this.handleInputChange} name="nombre" size="40" placeholder="First Name"/></p>
                       <p><input id="RI2" type="text" onChange={this.handleInputChange} name="apellido"size="40" placeholder="Last Name"/></p>
				       <h1 id="text-birthday">BirthDay</h1>
				       <p><input type="date" id="RI3" onChange={this.handleInputChange}/></p>

                        <p><input id="RI4" onChange={this.handleInputChange} type="text" size="40" placeholder="E-mail"/></p>
                        <p><input id="RI5" onChange={this.handleInputChange} type="text" size="40" placeholder="Address"/></p>
                        <p><input id="RI6" onChange={this.handleInputChange} type="text" size="40" placeholder="Phone"/></p>
                        <h1 id="text-Gender">Gender</h1>
                        <select id="RI7" >
                            <option value="1">Male  </option>
                            <option value="2">Female</option>
                            <option value="3">Other </option>
                        </select>

                        <p><input id="RI8" onChange={this.handleInputChange} type="text" size="40" placeholder="Password"/></p>
                        <p><input id="RI9" onChange={this.handleInputChange} type="text" size="40" placeholder="Confirm Password"/></p>

                        <h1 id="text-Payment">Payment Information</h1>
                        <p><input id="RI10" onChange={this.handleInputChange} type="text" size="40" placeholder="Card Number"/></p>
                        <select name='expireMonth' id='expireMonth'>
                            <option value=''>Month</option>
                            <option value='1'>January</option>
                            <option value='2'>February</option>
                            <option value='3'>March</option>
                            <option value='4'>April</option>
                            <option value='5'>May</option>
                            <option value='6'>June</option>
                            <option value='7'>July</option>
                            <option value='8'>August</option>
                            <option value='9'>September</option>
                            <option value='10'>October</option>
                            <option value='11'>November</option>
                            <option value='12'>December</option>
                        </select> 

                    <select name='expireYear' id='expireYear'>
                        <option value=''>Year</option>
                        <option value='1'>2019</option>
                        <option value='2'>2020</option>
                        <option value='3'>2021</option>
                        <option value='4'>2022</option>
                    </select> 
					
				    <button id="Enviar" type="button" onClick={this.handleResultClick}>Submit</button>
                    </form>
                   </section>

                  <img id="IMG" src={img} width="250" height="250"></img>
               </section>    
        </div>
          );
      };
    }

export default Content

